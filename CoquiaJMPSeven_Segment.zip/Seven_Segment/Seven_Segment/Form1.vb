﻿Public Class Form1

    Public Function clearPanel()
        Panel1.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel2.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel3.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel4.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel5.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel20.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel19.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel18.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel17.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel11.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel30.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel29.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel28.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel27.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel31.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel30.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel49.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel48.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel47.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel21.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel50.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel49.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel48.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel47.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel41.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel37.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel38.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel39.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
        Panel40.BackColor = System.Drawing.Color.FromArgb(50, 50, 50)
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        clearPanel()

        Panel1.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel2.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel3.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel4.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel5.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel11.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel21.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel31.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel41.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel20.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel30.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel40.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel50.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel47.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel48.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel49.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        clearPanel()

        Panel3.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel18.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel28.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel38.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel48.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        clearPanel()

        Panel1.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel2.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel3.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel4.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel5.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel11.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel31.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel37.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel38.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel39.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel40.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel30.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel50.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel49.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel48.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel47.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel41.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        clearPanel()

        Panel1.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel2.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel3.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel4.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel5.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel11.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel31.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel37.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel38.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel39.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel40.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel21.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel41.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel47.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel48.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel49.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel50.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        clearPanel()

        Panel1.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel11.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel20.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel40.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel38.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel39.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel37.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel5.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel11.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel21.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel31.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel41.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        clearPanel()

        Panel1.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel2.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel3.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel4.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel5.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel20.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel40.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel39.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel38.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel37.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel31.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel21.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel41.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel47.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel48.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel49.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel50.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        clearPanel()

        Panel1.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel2.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel3.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel4.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel5.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel20.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel30.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel40.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel50.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel47.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel48.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel49.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel31.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel21.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel37.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel38.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel39.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel41.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        clearPanel()

        Panel1.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel2.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel3.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel4.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel5.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel17.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel38.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel29.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel50.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        clearPanel()

        Panel1.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel2.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel3.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel4.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel5.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel20.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel40.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel39.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel38.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel37.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel11.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel31.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel30.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel50.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel49.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel48.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel47.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel41.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel21.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel31.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        clearPanel()

        Panel1.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel2.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel3.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel4.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel5.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel20.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel40.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel39.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel38.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel37.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel11.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel31.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel50.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel49.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel48.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel47.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel41.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel21.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
        Panel31.BackColor = System.Drawing.Color.FromArgb(204, 0, 0)
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        clearPanel()
    End Sub
End Class
