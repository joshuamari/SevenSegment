﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Panel49 = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.Panel50 = New System.Windows.Forms.Panel()
        Me.Panel48 = New System.Windows.Forms.Panel()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Panel47 = New System.Windows.Forms.Panel()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Panel41 = New System.Windows.Forms.Panel()
        Me.Panel46 = New System.Windows.Forms.Panel()
        Me.Panel45 = New System.Windows.Forms.Panel()
        Me.Panel44 = New System.Windows.Forms.Panel()
        Me.Panel43 = New System.Windows.Forms.Panel()
        Me.Panel42 = New System.Windows.Forms.Panel()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.Panel36 = New System.Windows.Forms.Panel()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel37 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel38 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel39 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel40 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Panel11.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel41.SuspendLayout()
        Me.Panel31.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label1.Location = New System.Drawing.Point(54, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(168, 24)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "PICK A NUMBER"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(43, 330)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(45, 45)
        Me.Button1.TabIndex = 26
        Me.Button1.Text = "0"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(177, 266)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(45, 45)
        Me.Button2.TabIndex = 27
        Me.Button2.Text = "1"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(111, 266)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(45, 45)
        Me.Button3.TabIndex = 28
        Me.Button3.Text = "2"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(43, 266)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(45, 45)
        Me.Button4.TabIndex = 29
        Me.Button4.Text = "3"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(177, 201)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(45, 45)
        Me.Button5.TabIndex = 30
        Me.Button5.Text = "4"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(43, 138)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(45, 45)
        Me.Button6.TabIndex = 35
        Me.Button6.Text = "9"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(111, 138)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(45, 45)
        Me.Button7.TabIndex = 34
        Me.Button7.Text = "8"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(177, 138)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(45, 45)
        Me.Button8.TabIndex = 33
        Me.Button8.Text = "7"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(43, 201)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(45, 45)
        Me.Button9.TabIndex = 32
        Me.Button9.Text = "6"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(111, 201)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(45, 45)
        Me.Button10.TabIndex = 31
        Me.Button10.Text = "5"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Panel49
        '
        Me.Panel49.BackColor = System.Drawing.Color.DimGray
        Me.Panel49.Location = New System.Drawing.Point(412, 349)
        Me.Panel49.Name = "Panel49"
        Me.Panel49.Size = New System.Drawing.Size(50, 50)
        Me.Panel49.TabIndex = 21
        '
        'Panel17
        '
        Me.Panel17.BackColor = System.Drawing.Color.DimGray
        Me.Panel17.Location = New System.Drawing.Point(567, 113)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(50, 50)
        Me.Panel17.TabIndex = 7
        '
        'Panel27
        '
        Me.Panel27.BackColor = System.Drawing.Color.DimGray
        Me.Panel27.Location = New System.Drawing.Point(567, 271)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(50, 50)
        Me.Panel27.TabIndex = 17
        '
        'Panel50
        '
        Me.Panel50.BackColor = System.Drawing.Color.DimGray
        Me.Panel50.Location = New System.Drawing.Point(335, 349)
        Me.Panel50.Name = "Panel50"
        Me.Panel50.Size = New System.Drawing.Size(50, 50)
        Me.Panel50.TabIndex = 19
        '
        'Panel48
        '
        Me.Panel48.BackColor = System.Drawing.Color.DimGray
        Me.Panel48.Location = New System.Drawing.Point(489, 349)
        Me.Panel48.Name = "Panel48"
        Me.Panel48.Size = New System.Drawing.Size(50, 50)
        Me.Panel48.TabIndex = 20
        '
        'Panel28
        '
        Me.Panel28.BackColor = System.Drawing.Color.DimGray
        Me.Panel28.Location = New System.Drawing.Point(489, 271)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(50, 50)
        Me.Panel28.TabIndex = 15
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.DimGray
        Me.Panel11.Controls.Add(Me.Panel12)
        Me.Panel11.Controls.Add(Me.Panel13)
        Me.Panel11.Controls.Add(Me.Panel14)
        Me.Panel11.Controls.Add(Me.Panel15)
        Me.Panel11.Controls.Add(Me.Panel16)
        Me.Panel11.Location = New System.Drawing.Point(645, 113)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(50, 50)
        Me.Panel11.TabIndex = 8
        '
        'Panel16
        '
        Me.Panel16.BackColor = System.Drawing.Color.Black
        Me.Panel16.Location = New System.Drawing.Point(-310, 78)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(60, 60)
        Me.Panel16.TabIndex = 4
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.Black
        Me.Panel15.Location = New System.Drawing.Point(-233, 78)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(60, 60)
        Me.Panel15.TabIndex = 6
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.Color.Black
        Me.Panel14.Location = New System.Drawing.Point(-156, 78)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(60, 60)
        Me.Panel14.TabIndex = 5
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.Black
        Me.Panel13.Location = New System.Drawing.Point(-78, 78)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(60, 60)
        Me.Panel13.TabIndex = 7
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.Black
        Me.Panel12.Location = New System.Drawing.Point(0, 78)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(60, 60)
        Me.Panel12.TabIndex = 8
        '
        'Panel18
        '
        Me.Panel18.BackColor = System.Drawing.Color.DimGray
        Me.Panel18.Location = New System.Drawing.Point(489, 113)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(50, 50)
        Me.Panel18.TabIndex = 5
        '
        'Panel47
        '
        Me.Panel47.BackColor = System.Drawing.Color.DimGray
        Me.Panel47.Location = New System.Drawing.Point(567, 349)
        Me.Panel47.Name = "Panel47"
        Me.Panel47.Size = New System.Drawing.Size(50, 50)
        Me.Panel47.TabIndex = 22
        '
        'Panel29
        '
        Me.Panel29.BackColor = System.Drawing.Color.DimGray
        Me.Panel29.Location = New System.Drawing.Point(412, 271)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(50, 50)
        Me.Panel29.TabIndex = 16
        '
        'Panel21
        '
        Me.Panel21.BackColor = System.Drawing.Color.DimGray
        Me.Panel21.Controls.Add(Me.Panel22)
        Me.Panel21.Controls.Add(Me.Panel23)
        Me.Panel21.Controls.Add(Me.Panel24)
        Me.Panel21.Controls.Add(Me.Panel25)
        Me.Panel21.Controls.Add(Me.Panel26)
        Me.Panel21.Location = New System.Drawing.Point(645, 271)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(50, 50)
        Me.Panel21.TabIndex = 18
        '
        'Panel26
        '
        Me.Panel26.BackColor = System.Drawing.Color.Black
        Me.Panel26.Location = New System.Drawing.Point(-310, 78)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(60, 60)
        Me.Panel26.TabIndex = 4
        '
        'Panel25
        '
        Me.Panel25.BackColor = System.Drawing.Color.Black
        Me.Panel25.Location = New System.Drawing.Point(-233, 78)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(60, 60)
        Me.Panel25.TabIndex = 6
        '
        'Panel24
        '
        Me.Panel24.BackColor = System.Drawing.Color.Black
        Me.Panel24.Location = New System.Drawing.Point(-156, 78)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(60, 60)
        Me.Panel24.TabIndex = 5
        '
        'Panel23
        '
        Me.Panel23.BackColor = System.Drawing.Color.Black
        Me.Panel23.Location = New System.Drawing.Point(-78, 78)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(60, 60)
        Me.Panel23.TabIndex = 7
        '
        'Panel22
        '
        Me.Panel22.BackColor = System.Drawing.Color.Black
        Me.Panel22.Location = New System.Drawing.Point(0, 78)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(60, 60)
        Me.Panel22.TabIndex = 8
        '
        'Panel19
        '
        Me.Panel19.BackColor = System.Drawing.Color.DimGray
        Me.Panel19.Location = New System.Drawing.Point(412, 113)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(50, 50)
        Me.Panel19.TabIndex = 6
        '
        'Panel41
        '
        Me.Panel41.BackColor = System.Drawing.Color.DimGray
        Me.Panel41.Controls.Add(Me.Panel42)
        Me.Panel41.Controls.Add(Me.Panel43)
        Me.Panel41.Controls.Add(Me.Panel44)
        Me.Panel41.Controls.Add(Me.Panel45)
        Me.Panel41.Controls.Add(Me.Panel46)
        Me.Panel41.Location = New System.Drawing.Point(645, 349)
        Me.Panel41.Name = "Panel41"
        Me.Panel41.Size = New System.Drawing.Size(50, 50)
        Me.Panel41.TabIndex = 23
        '
        'Panel46
        '
        Me.Panel46.BackColor = System.Drawing.Color.Black
        Me.Panel46.Location = New System.Drawing.Point(-310, 78)
        Me.Panel46.Name = "Panel46"
        Me.Panel46.Size = New System.Drawing.Size(60, 60)
        Me.Panel46.TabIndex = 4
        '
        'Panel45
        '
        Me.Panel45.BackColor = System.Drawing.Color.Black
        Me.Panel45.Location = New System.Drawing.Point(-233, 78)
        Me.Panel45.Name = "Panel45"
        Me.Panel45.Size = New System.Drawing.Size(60, 60)
        Me.Panel45.TabIndex = 6
        '
        'Panel44
        '
        Me.Panel44.BackColor = System.Drawing.Color.Black
        Me.Panel44.Location = New System.Drawing.Point(-156, 78)
        Me.Panel44.Name = "Panel44"
        Me.Panel44.Size = New System.Drawing.Size(60, 60)
        Me.Panel44.TabIndex = 5
        '
        'Panel43
        '
        Me.Panel43.BackColor = System.Drawing.Color.Black
        Me.Panel43.Location = New System.Drawing.Point(-78, 78)
        Me.Panel43.Name = "Panel43"
        Me.Panel43.Size = New System.Drawing.Size(60, 60)
        Me.Panel43.TabIndex = 7
        '
        'Panel42
        '
        Me.Panel42.BackColor = System.Drawing.Color.Black
        Me.Panel42.Location = New System.Drawing.Point(0, 78)
        Me.Panel42.Name = "Panel42"
        Me.Panel42.Size = New System.Drawing.Size(60, 60)
        Me.Panel42.TabIndex = 8
        '
        'Panel30
        '
        Me.Panel30.BackColor = System.Drawing.Color.DimGray
        Me.Panel30.Location = New System.Drawing.Point(335, 271)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(50, 50)
        Me.Panel30.TabIndex = 14
        '
        'Panel20
        '
        Me.Panel20.BackColor = System.Drawing.Color.DimGray
        Me.Panel20.Location = New System.Drawing.Point(335, 113)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(50, 50)
        Me.Panel20.TabIndex = 4
        '
        'Panel31
        '
        Me.Panel31.BackColor = System.Drawing.Color.DimGray
        Me.Panel31.Controls.Add(Me.Panel32)
        Me.Panel31.Controls.Add(Me.Panel33)
        Me.Panel31.Controls.Add(Me.Panel34)
        Me.Panel31.Controls.Add(Me.Panel35)
        Me.Panel31.Controls.Add(Me.Panel36)
        Me.Panel31.Location = New System.Drawing.Point(645, 191)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(50, 50)
        Me.Panel31.TabIndex = 13
        '
        'Panel36
        '
        Me.Panel36.BackColor = System.Drawing.Color.Black
        Me.Panel36.Location = New System.Drawing.Point(-310, 80)
        Me.Panel36.Name = "Panel36"
        Me.Panel36.Size = New System.Drawing.Size(60, 60)
        Me.Panel36.TabIndex = 4
        '
        'Panel35
        '
        Me.Panel35.BackColor = System.Drawing.Color.Black
        Me.Panel35.Location = New System.Drawing.Point(-233, 80)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(60, 60)
        Me.Panel35.TabIndex = 6
        '
        'Panel34
        '
        Me.Panel34.BackColor = System.Drawing.Color.Black
        Me.Panel34.Location = New System.Drawing.Point(-156, 80)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(60, 60)
        Me.Panel34.TabIndex = 5
        '
        'Panel33
        '
        Me.Panel33.BackColor = System.Drawing.Color.Black
        Me.Panel33.Location = New System.Drawing.Point(-78, 80)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(60, 60)
        Me.Panel33.TabIndex = 7
        '
        'Panel32
        '
        Me.Panel32.BackColor = System.Drawing.Color.Black
        Me.Panel32.Location = New System.Drawing.Point(0, 80)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(60, 60)
        Me.Panel32.TabIndex = 8
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.DimGray
        Me.Panel5.Controls.Add(Me.Panel6)
        Me.Panel5.Controls.Add(Me.Panel7)
        Me.Panel5.Controls.Add(Me.Panel8)
        Me.Panel5.Controls.Add(Me.Panel9)
        Me.Panel5.Controls.Add(Me.Panel10)
        Me.Panel5.Location = New System.Drawing.Point(645, 33)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(50, 50)
        Me.Panel5.TabIndex = 3
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.Black
        Me.Panel10.Location = New System.Drawing.Point(-310, 80)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(60, 60)
        Me.Panel10.TabIndex = 4
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.Black
        Me.Panel9.Location = New System.Drawing.Point(-233, 80)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(60, 60)
        Me.Panel9.TabIndex = 6
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.Black
        Me.Panel8.Location = New System.Drawing.Point(-156, 80)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(60, 60)
        Me.Panel8.TabIndex = 5
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.Black
        Me.Panel7.Location = New System.Drawing.Point(-78, 80)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(60, 60)
        Me.Panel7.TabIndex = 7
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Black
        Me.Panel6.Location = New System.Drawing.Point(0, 80)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(60, 60)
        Me.Panel6.TabIndex = 8
        '
        'Panel37
        '
        Me.Panel37.BackColor = System.Drawing.Color.DimGray
        Me.Panel37.Location = New System.Drawing.Point(567, 191)
        Me.Panel37.Name = "Panel37"
        Me.Panel37.Size = New System.Drawing.Size(50, 50)
        Me.Panel37.TabIndex = 12
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.DimGray
        Me.Panel4.Location = New System.Drawing.Point(567, 33)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(50, 50)
        Me.Panel4.TabIndex = 2
        '
        'Panel38
        '
        Me.Panel38.BackColor = System.Drawing.Color.DimGray
        Me.Panel38.Location = New System.Drawing.Point(489, 191)
        Me.Panel38.Name = "Panel38"
        Me.Panel38.Size = New System.Drawing.Size(50, 50)
        Me.Panel38.TabIndex = 10
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.DimGray
        Me.Panel3.Location = New System.Drawing.Point(489, 33)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(50, 50)
        Me.Panel3.TabIndex = 1
        '
        'Panel39
        '
        Me.Panel39.BackColor = System.Drawing.Color.DimGray
        Me.Panel39.Location = New System.Drawing.Point(412, 191)
        Me.Panel39.Name = "Panel39"
        Me.Panel39.Size = New System.Drawing.Size(50, 50)
        Me.Panel39.TabIndex = 11
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.DimGray
        Me.Panel2.Location = New System.Drawing.Point(412, 33)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(50, 50)
        Me.Panel2.TabIndex = 1
        '
        'Panel40
        '
        Me.Panel40.BackColor = System.Drawing.Color.DimGray
        Me.Panel40.Location = New System.Drawing.Point(335, 191)
        Me.Panel40.Name = "Panel40"
        Me.Panel40.Size = New System.Drawing.Size(50, 50)
        Me.Panel40.TabIndex = 9
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DimGray
        Me.Panel1.Location = New System.Drawing.Point(335, 33)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(50, 50)
        Me.Panel1.TabIndex = 0
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(111, 330)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(111, 45)
        Me.Button11.TabIndex = 36
        Me.Button11.Text = "CLEAR"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel40)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Panel39)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Panel38)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Panel37)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Panel31)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Panel20)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Panel30)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel41)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel19)
        Me.Controls.Add(Me.Panel49)
        Me.Controls.Add(Me.Panel21)
        Me.Controls.Add(Me.Panel17)
        Me.Controls.Add(Me.Panel29)
        Me.Controls.Add(Me.Panel27)
        Me.Controls.Add(Me.Panel47)
        Me.Controls.Add(Me.Panel50)
        Me.Controls.Add(Me.Panel18)
        Me.Controls.Add(Me.Panel48)
        Me.Controls.Add(Me.Panel11)
        Me.Controls.Add(Me.Panel28)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Seven Segment Display"
        Me.Panel11.ResumeLayout(False)
        Me.Panel21.ResumeLayout(False)
        Me.Panel41.ResumeLayout(False)
        Me.Panel31.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Panel49 As Panel
    Friend WithEvents Panel17 As Panel
    Friend WithEvents Panel27 As Panel
    Friend WithEvents Panel50 As Panel
    Friend WithEvents Panel48 As Panel
    Friend WithEvents Panel28 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Panel18 As Panel
    Friend WithEvents Panel47 As Panel
    Friend WithEvents Panel29 As Panel
    Friend WithEvents Panel21 As Panel
    Friend WithEvents Panel22 As Panel
    Friend WithEvents Panel23 As Panel
    Friend WithEvents Panel24 As Panel
    Friend WithEvents Panel25 As Panel
    Friend WithEvents Panel26 As Panel
    Friend WithEvents Panel19 As Panel
    Friend WithEvents Panel41 As Panel
    Friend WithEvents Panel42 As Panel
    Friend WithEvents Panel43 As Panel
    Friend WithEvents Panel44 As Panel
    Friend WithEvents Panel45 As Panel
    Friend WithEvents Panel46 As Panel
    Friend WithEvents Panel30 As Panel
    Friend WithEvents Panel20 As Panel
    Friend WithEvents Panel31 As Panel
    Friend WithEvents Panel32 As Panel
    Friend WithEvents Panel33 As Panel
    Friend WithEvents Panel34 As Panel
    Friend WithEvents Panel35 As Panel
    Friend WithEvents Panel36 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel37 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel38 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel39 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel40 As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button11 As Button
End Class
